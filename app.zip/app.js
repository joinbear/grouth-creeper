
var 
  creeperCtr  = require('./controller'),
  creeper     = new creeperCtr(),
  schedule    = require('node-schedule'),
  rule        = new schedule.RecurrenceRule();
  rule.hours  = [8,9,10,11,12,13,14,15,16,17,18]; 
  rule.minute = 1;

var j = schedule.scheduleJob(rule, function(){
  creeper.getWuBaData('http://cd.58.com');
  creeper.getAnjukeData('http://chengdu.anjuke.com/');
  console.log("执行任务");
});
creeper.getWuBaData('http://cd.58.com');
creeper.getAnjukeData('http://chengdu.anjuke.com/');
// var 
// 	superagent = require('superagent'),
// 	cheerio    = require('cheerio'),
// 	urlUtil    = require('url');
// var querystring=require("querystring");

// var contents=querystring.stringify({
// 	j_username:"20110553",
// 	j_password:"zm123456",
// 	j_redirectto:"/ekp/home.jsp"
// });
// var url = 'http://api.ecen.com.cn/ekp/j_acegi_security_check';
// superagent
// 	.post(url)
// 	.set('Pragma','no-cache')
// 	.set("Content-Type","application/x-www-form-urlencoded; charset=UTF-8")
// 	.set('User-Agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36')
// 	.send(contents)
// 	.end(function (err, res) {
// 	  if (err) {
// 	    return console.error(err);
// 	  }
// 	  var cookies = res.headers['set-cookie'];
// 	  console.log(cookies);
// 	  console.log(res.redirects[0]);
// 	  superagent
// 	  .get(res.redirects[0])
// 		.set('Pragma','no-cache')
// 		.set('Cookie',cookies.join(';'))
// 		.set('User-Agent','Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2490.71 Safari/537.36')
// 		.end(function (err, res) {
// 			if (err) {
// 		    return console.error(err);
// 		  }
// 		  console.log('=============');
// 		  console.log(res.text);
// 		});

// 	});